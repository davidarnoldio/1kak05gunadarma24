// Particle Animation
function createParticles() {
  const container = document.body;
  for (let i = 0; i < 30; i++) {
    const particle = document.createElement("div");
    particle.className = "particle";
    particle.style.left = Math.random() * 100 + "%";
    particle.style.animationDelay = Math.random() * 4 + "s";

    // Add click event to particles
    particle.addEventListener("click", () => {
      changeBackgroundColor();
      playClickSound();
    });

    // Add hover effect
    particle.addEventListener("mouseover", () => {
      particle.style.transform = "scale(1.5)";
    });

    particle.addEventListener("mouseout", () => {
      particle.style.transform = "scale(1)";
    });

    container.appendChild(particle);
  }
}
createParticles();

// Function to change background color
function changeBackgroundColor() {
  const colors = ["#FF5733", "#33FF57", "#3357FF", "#F3FF33", "#FF33A1"];
  document.body.style.backgroundColor =
    colors[Math.floor(Math.random() * colors.length)];
}

// Function to play sound
function playClickSound() {
  const audio = new Audio("click-sound.mp3"); // Replace with a valid sound file URL
  audio.play();
}

// Form Handling
document.getElementById("contactForm").addEventListener("submit", (e) => {
  e.preventDefault();
  alert("Message sent successfully!");
  e.target.reset();
});
